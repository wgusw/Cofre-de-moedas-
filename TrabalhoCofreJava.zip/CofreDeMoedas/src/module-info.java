/**
 * 
 */
/**
 * 
 */
module CofreDeMoedas {
}