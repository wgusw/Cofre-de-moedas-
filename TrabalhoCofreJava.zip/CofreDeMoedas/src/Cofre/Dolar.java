package Cofre;

public class Dolar extends Moeda {
	

	@Override
	public void info() { //usando método info() para imprimir valores 
		  System.out.println("Moeda: Dólar. Valor: $" + this.mostrarValor());
		
	}
	
	@Override
	public double converter() { //convertendo dolar para o real
		
		double totalDolar = valor * 4.87;
		return totalDolar;
		
	}
	
	public Dolar(double valor) {
	super(valor);
	
	}
	
	double mostrarValor() {
		double total = valor;
		return total;
	
	}
	
}
