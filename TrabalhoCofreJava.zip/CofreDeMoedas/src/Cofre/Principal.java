package Cofre;
	import java.util.Scanner;
	
	
	//Gustavo Henrique. 
	//Aluno Uninter
	
	

	public class Principal {
		public static void main(String[] args) {
		 
			Scanner valordinheiro = new Scanner(System.in);
			int NumeroEscolhido;
			
			Cofrinho cofre = new Cofrinho();
			
			System.out.println("COFRINHO"); //MENU PRINCIPAL
			System.out.println("1 - Adicionar moeda");	
			System.out.println("2 - Remover moeda");
			System.out.println("3 - Listar moedas");
			System.out.println("4 - Total convertido");
			System.out.println("0 - Encerrar");
			NumeroEscolhido = valordinheiro.nextInt();//comando que permite a escolha de uma opção
			
			int tipoMoeda;
			double valor;
			Moeda moedas; 
			//iniciando o loop
			while(NumeroEscolhido != 0) {
				
				switch(NumeroEscolhido) {
				
				case 1: //caso escoclha opção 1
					tipoMoeda = 0;
					while(tipoMoeda>3 || tipoMoeda<=0) { //verifica se as opções serão escritas corretamente 
				    System.out.println("Selecione o tipo da moeda:");
					System.out.println("1 - Real");
					System.out.println("2 - Euro");
					System.out.println("3 - Dolar");
					tipoMoeda = valordinheiro.nextInt();
					
					}
					//escolha o tipo e valores serão adicionados na lista
					moedas = null;
					if(tipoMoeda == 1) {
						System.out.println("Qual é o valor da moeda: ");
						valor = valordinheiro.nextDouble();
						moedas = new Real(valor);
					
					}
						
					if(tipoMoeda == 2) {
						System.out.println("Qual é o valor da moeda: ");
						valor = valordinheiro.nextDouble();
						moedas = new Euro(valor);	
					
					}
					
					if(tipoMoeda == 3) {
						System.out.println("Qual é o valor da moeda: ");
						valor = valordinheiro.nextDouble();
						moedas = new Dolar(valor);
					
					}	
						
						cofre.adicionar(moedas); //adicionará o valor obtido na lista
					
					break;
					
				case 2: //caso escolha opção 2
					tipoMoeda = 0;
					while(tipoMoeda>3 || tipoMoeda<=0) {
					System.out.println("Selecione o tipo da moeda:");
					System.out.println("1 - Real");
					System.out.println("2 - Euro");
					System.out.println("3 - Dolar");
					tipoMoeda = valordinheiro.nextInt();
					
					}
					
					moedas = null;
					if(tipoMoeda == 1) {
						System.out.println("Qual é o valor da moeda: ");
						valor = valordinheiro.nextDouble();
						moedas = new Real(valor);
					
					}
						
					if(tipoMoeda == 2) {
						System.out.println(" Qual o valor da moeda? ");
						valor = valordinheiro.nextDouble();
						moedas = new Euro(valor);	
					
					}
					
					if(tipoMoeda == 3) {
						System.out.println("Qual é o valor da moeda? ");
						valor = valordinheiro.nextDouble();
						moedas = new Dolar(valor);
						
					}
					
						cofre.remover(moedas); //comando de remover
					
					break;
					
				case 3: //caso escolha opção 3
					cofre.listas(); 
					break;
				
				case 4: //caso escolha opção 4
					double total = cofre.totalConvertido();
					System.out.println("O valor total convertido em Real é: R$" + total);
					break; 
					
				default: //caso digite um valor inválido/diferente do apresentado
					System.out.println("Opção inválida, tente novamente ");
					
				}
				
				System.out.println("COFRINHO");
				System.out.println("1 - Adicionar moeda");	
				System.out.println("2 - Remover moeda");
				System.out.println("3 - Listar moedas");
				System.out.println("4 - Total convertido");
				System.out.println("0 - Encerrar");
				NumeroEscolhido = valordinheiro.nextInt(); //verifica se o scanner foi um numero inteiro
			}
			
		}

	}

