package Cofre;

import java.util.Objects;

public abstract class Moeda { //classe abstrata
	double valor;
	
	public Moeda(double valor) {
		
		super();
		this.valor = valor;
	}
	
	public abstract void info();
	public abstract double converter();

	@Override
	public int hashCode() {
		return Objects.hash(valor);
	
	}

	
}