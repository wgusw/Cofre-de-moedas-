package Cofre;
public class Euro extends Moeda {
	
	
	@Override
	public void info() { //usando método info() para imprimir valores 
		System.out.println("Moeda: Euro. Valor: €" + this.mostrarValor());	
	
	}
	
	@Override
	public double converter() { //euro convertido para real
		
		double totalEuro = valor * 5.34; 
		return totalEuro;
	
	}
	
	public Euro(double valor) {
	super(valor);
	
	}
	
	double mostrarValor() {
		double total = valor;
		return total;
	
	}


} 