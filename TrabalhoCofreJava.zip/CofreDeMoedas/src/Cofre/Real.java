package Cofre;

public class Real extends Moeda {
	
	@Override
	public void info() { //usando método info() para imprimir valores 
		System.out.println("Moeda: Real. Valor: R$" + this.mostrarReal());	
	
	}
	
	@Override
	public double converter() { // conversão de acordo com o valor normal
		return valor;
	
	}
	
	public Real(double valor) { //usando valor normal da classe mãe
	super(valor);
	
	}
	
	double mostrarReal() { //
		
		double total = valor;
		return total;	
	
	}


}