package Cofre;
import java.util.ArrayList;

public class Cofrinho {
	ArrayList<Moeda> listarMoedas = new ArrayList<Moeda>(); //lista de moedas
	
	public void adicionar(Moeda m) { // Dando para a classe Moeda uma referencia "m"
		listarMoedas.add(m);          //assim pode-se adicionar com mais facilidade
	
	}
	
	public void remover(Moeda m) { // usando a referencia "M" para remover o valor
		listarMoedas.remove(m);
	
	}
	
	public void listas() { //método de listagem dos valores obtidos
		
		for (Moeda m: listarMoedas) {
			m.info();
		}		
	
	}
	
	public double totalConvertido() { //mostra o total convertido em BRL
		if(this.listarMoedas.isEmpty()) {//caso esteja vazio a lista, retorna 0
		return 0;   
	
		}
		//mostra o total convertido em BRL
		double Acumulado = 0;
		
		for (Moeda m: this.listarMoedas) {
			Acumulado = Acumulado + m.converter();
			}
	
		return Acumulado;
	
	}

}
